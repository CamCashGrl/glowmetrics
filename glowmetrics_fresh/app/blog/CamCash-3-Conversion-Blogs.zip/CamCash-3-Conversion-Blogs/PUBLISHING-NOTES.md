# Three New Conversion Blogs

## Routes

1. `/blog/spin-the-wheel-cam-game`
   - Primary conversion: Pretty Profitz Spin-the-Wheel Template Pack
   - Secondary conversion: CamCash session analytics

2. `/blog/live-mode-coaching-for-cam-models`
   - Primary conversion: CamCash Live Mode
   - Explains dead-air, pace, goal, whale, and fatigue prompts

3. `/blog/whale-watch-for-cam-models`
   - Primary conversion: CamCash Whale Watch
   - Secondary conversion: Pretty Profitz VIP Client Tracker

## Compatibility

Each post uses:
`import ArticleLayout from '../../components/ArticleLayout'`

Place each `page.js` in:
`app/blog/<slug>/page.js`

## Verify Before Publishing

- Confirm `PRETTY70` is active.
- Replace the generic Pretty Profitz shop URL with the exact product link when available.
- Confirm `/login` is the intended CTA for Live Mode and Whale Watch.
- Confirm these features are publicly available before indexing the feature-led posts.
